
    $(document).ready(function() {
        // Initiate counterUp on your element
        $('[data-toggle="counter-up"]').counterUp({
            delay: 10, // Delay in milliseconds per count increment
            time: 1000 // Total time taken for animation in milliseconds
        });
    });

